const express = require('express');
const mongoose = require('mongoose');
const userRouter = require('./routes/userrouter');
const articleRouter = require('./routes/articlerouter');
const indexRouter = require('./routes/indexrouter');

const app = express();

// Connect to MongoDB
mongoose.connect('mongodb+srv://khangngo141003:khangminh123@webprojectgroup7.9nvh4ct.mongodb.net/', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => {
  console.log('Connected to MongoDB');
})
.catch((err) => {
  console.error('Error connecting to MongoDB:', err);
});

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Routes
app.use('/user', userRouter);
app.use('/article', articleRouter);
app.use('/', indexRouter);

const port = 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
