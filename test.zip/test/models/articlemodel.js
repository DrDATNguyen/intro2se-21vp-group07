const mongoose = require('mongoose');

const articleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: String,
  content: { type: String, required: true },
  datecreated: { type: Date, default: Date.now, required: true },
  author: { type: String, required: true },
  comments: [
    {
      name: String,
      comment: String,
    },
  ],
  img: String,
  video: String,
  
});

const Article = mongoose.model('Article', articleSchema);

module.exports = Article;
