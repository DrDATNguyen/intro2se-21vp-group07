const express = require('express');
const router = express.Router();
const Article = require('../models/articlemodel');

router.get('/create', (req, res) => {
  res.render('createArticle');
});

router.post('/create', (req, res) => {
  const article = new Article({
    title : req.params.title,
    description: req.params.description,
    content: req.params.content
  })
  try{
    article = article.save()
    res.redirect('/article/${article.id}')
  }
  catch(error){
    console.log(error)
    res.render('/article/createArticles', {article: article})  
  }
  res.redirect('/homeUser');
});

router.get('/list', async (req, res) => {
  try {
    // Retrieve a list of articles from the database and pass them to the eacharticle.ejs view
    const articles = await Article.find().select('title author img description datecreated');
    res.render('eacharticle', { articles });
  } catch (err) {
    console.error(err);
    res.status(500).send('An error occurred while loading the articles.');
  }
});

module.exports = router;
